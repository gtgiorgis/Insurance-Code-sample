package insurance.polcyregistration;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class PolicyProcessorTest {

	@Test
	public void testPolicyCalculate() {

		List<VehicleInfo> vehicles = new ArrayList<VehicleInfo>();

		CoverageDiscount coverageDisoount = new CoverageDiscount();
		VehicleInfo vehicle = new VehicleInfo();
		InsuredPersonInfo person = new InsuredPersonInfo();
		
		PolicySummary policy = new PolicySummary();

		policy.setDisount(coverageDisoount);
		policy.setPerson(person);
		policy.setVehicles(vehicles);
		
		
		vehicle.setNameOfVehicle("Honda");
		vehicle.setNumOfDoors(4);
		vehicle.setYearMade(2014);
		person.setAge(55);
		coverageDisoount.setDrivingExperience(6);
		coverageDisoount.setNumOfAccidents(0);
		vehicles.add(vehicle);
		
		assertEquals(1000, new PolicyRateCalculator().calculateRate(policy));
		// assertEquals(17, new PolicyRateCalculator().calculateAge(2000));
		

		/*
		 * use the same package in JUnit Test and source man. they have to be identical
		 * JUnit builds test data calls method (in man source java)is written as public
		 * void test methodName outcome(){ assertEquals(expectedVale, actualValue );
		 * assertTrue assert assertEquals (1000, 1000) this can not pass assertEquals
		 * (1000.00, 200/20) this will not pass and does assertion will have public
		 * method will always will be void uses @Test above the method
		 * 
		 * naming convention is no arguments class name of Junit is the class name of
		 * the source man class plus Test.
		 */

	}

	@Test

	public void testLoopValues() {
		List<VehicleInfo> vehicles = new ArrayList<VehicleInfo>();
		PolicySummary policy = new PolicySummary();

		VehicleInfo vehicle = new VehicleInfo();

		vehicle.setNumOfDoors(4);
		vehicle.setNameOfVehicle("Honda");
		vehicle.setYearMade(2016);
		policy.setVehicles(vehicles);
		
		// List<VehicleInfo> vehicles = new ArrayList<VehicleInfo>(); for list of
		// vehicles
		vehicles.add(vehicle);
		// policy.setVehicles(vehicles); this to have lists of vehicles in the policy
		

		CoverageDiscount coverageDiscount = new CoverageDiscount();
		coverageDiscount.setDrivingExperience(6);
		coverageDiscount.setNumOfAccidents(0);
		coverageDiscount.setHowOld(45);
		policy.setDisount(coverageDiscount);
		// List<VehicleInfo> vehicles = new ArrayList<VehicleInfo>();

		InsuredPersonInfo person = new InsuredPersonInfo();

		person.setLastName("Tgiorgis");
		person.setAge(70);
		policy.setPerson(person);

		// CoverageDiscount coverageDisoount = new CoverageDiscount();

		assertEquals(900, new PolicyRateCalculator().calculateRate(policy));

	}
}
